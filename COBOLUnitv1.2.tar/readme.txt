UNDER UBUNTU :
-------------

*************
* COBOLUNIT *
*************
- COBOLUnit Build configuration: 
	All the configuration files are stores under /COBOLUnit/Build
	- ENV.SCRIPT:
		this configuration file set environment informations
		Open file COBOLUnit/Build/env.script
		Set your own paths: 
			=> CBU_PATH= COBOLUnit installation path

	- BUILD.SH:
		Shell script launching the COBOLUnit make

	- MAKEFILE
- COBOLUnit Build:
	1/ $ cd %YOURPATH%/COBOLUnit/Build
	2/ $ source env.script
	3/ $ ./build.sh
	Check that your build is a success you should see 

		rm -rf *.so
		rm -rf ../lib/
		mkdir ../lib/
		cobc -std=mf -o libCOBOLUnit -I %YOURPATH%/COBOLUnit/CPY -b  %YOURPATH%/COBOLUnit/PGM/CBUP0001.CBL %YOURPATH%/COBOLUnit/PGM/CBUP0002.CBL %YOURPATH%/COBOLUnit/PGM/CBUP0003.CBL %YOURPATH%/COBOLUnit/PGM/CBUP0004.CBL %YOURPATH%/COBOLUnit/PGM/CBUP0005.CBL %YOURPATH%/COBOLUnit/PGM/CBUDUMP.CBL
		mv *.so ../lib/


******************
* COBOLUNITTESTS *
******************
- COBOLUnitTests Build configuration: 
	All the configuration files are stored under /COBOLUnitTests/Build

	- ENV.SCRIPT:
		this configuration file set environment informations
		Open file COBOLUniTestst/Build/env.script
		Set your own paths: 
			=> CBU_PATH= COBOLUnit installation path
			=> SAMPLE1_PATH= COBOLUnitTests path
	- BUILD.SH:
		Shell script launching the COBOLUnitTests make
	- MAKEFILE
	
- COBOLUnitTests Build
	1/ $ cd %YOURPATH%/CobolUnitTests/Build
	2/ $ source env.script
	3/ $ ./build.sh
	Check that your build is a success you should see a list of warnings ("file not terminated by a new line") and 
	mv libTS11.so ../tests/lib/
	cobc -x -I %YOURPATH%/COBOLUnit/CPY -I %YOURPATH%/COBOLUnitTests/CPY %YOURPATH%/COBOLUnitTests/PGM/CBUBATCH.cbl  -L %YOURPATH%/COBOLUnitTests/tests/lib -l TS11 -L %YOURPATH%/COBOLUnit/lib -l COBOLUnit
%YOURPATH%/COBOLUnitTests/PGM/CBUBATCH.cbl:12: Warning: File not terminated by a newline
mv ./CBUBATCH ../tests/

- COBOLUnitTests Run:
	1/ $ ./testCbu.sh 
	2/ system should return
	"WARNING - Implicit CLOSE of LogFile ("CBUPRINT.DAT")"
	3/ Open CBUPRINT.DAT file and read CBU tests results
)



